// components/InputField.js
import React from 'react';
import { View, Text, TextInput } from 'react-native';
import styles from '../styles/style';

const InputField = ({ label, value, onChangeText }) => {
  return (
    <View style={styles.inputContainer}>
      <Text>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChangeText}
        keyboardType="numeric"
      />
    </View>
  );
};

export default InputField;

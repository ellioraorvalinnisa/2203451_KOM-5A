import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';
import InputField from './components/InputField';
import styles from './styles/style'; 

const App = () => {
  const [length, setLength] = useState('');
  const [width, setWidth] = useState('');
  const [area, setArea] = useState(0);

  const calculateArea = () => {
    const l = parseFloat(length);
    const w = parseFloat(width);
    if (!isNaN(l) && !isNaN(w)) {
      setArea(l * w);
    } else {
      setArea(0);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hitung Luas Persegi Panjang</Text>
      
      {/* Length Input */}
      <InputField
        label="Masukkan Panjang"
        value={length}
        onChangeText={setLength}
      />

      {/* Width Input */}
      <InputField
        label="Masukkan Lebar"
        value={width}
        onChangeText={setWidth}
      />

      {/* Button to Calculate */}
      <Button title="Hitung" onPress={calculateArea} />

      {/* Display Result */}
      <Text style={styles.result}>Luas Persegi Panjang: {area}</Text>
    </View>
  );
};

export default App;
